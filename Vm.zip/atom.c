#include <stdio.h>
#include <stdlib.h>


#include "lexer.h"
#include "utils.h"
#include "parser.h"
#include "ad.h"
#include "vm.h"

int main()
{
  
    char *inbuf = loadFile("tests/testat.c");
    
    Token *tokens = tokenize(inbuf);      
                  
    free(inbuf);
    //showTokens(tokens);
    
    pushDomain();
    vmInit();

    parse(tokens);
    //showDomain(symTable,"global");

    Instr *testCode = genTestProgram();
    //Instr *testCode = MV();
    run(testCode); // executie cod masina virtuala
    dropDomain();
    
    return 0;
}
